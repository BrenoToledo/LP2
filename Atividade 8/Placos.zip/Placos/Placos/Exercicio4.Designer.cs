﻿namespace Placos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Calcular = new System.Windows.Forms.Button();
            this.txt_Nome = new System.Windows.Forms.TextBox();
            this.lbl_Nome = new System.Windows.Forms.Label();
            this.lbl_Cargo = new System.Windows.Forms.Label();
            this.txt_Cargo = new System.Windows.Forms.TextBox();
            this.lbl_Matricula = new System.Windows.Forms.Label();
            this.txt_Matricula = new System.Windows.Forms.TextBox();
            this.lbl_Producao = new System.Windows.Forms.Label();
            this.txt_Producao = new System.Windows.Forms.TextBox();
            this.lbl_Salario = new System.Windows.Forms.Label();
            this.txt_Salario = new System.Windows.Forms.TextBox();
            this.lbl_Gratificacao = new System.Windows.Forms.Label();
            this.txt_Gratificacao = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_Calcular
            // 
            this.btn_Calcular.Location = new System.Drawing.Point(99, 299);
            this.btn_Calcular.Name = "btn_Calcular";
            this.btn_Calcular.Size = new System.Drawing.Size(285, 23);
            this.btn_Calcular.TabIndex = 0;
            this.btn_Calcular.Text = "CALCULAR";
            this.btn_Calcular.UseVisualStyleBackColor = true;
            this.btn_Calcular.Click += new System.EventHandler(this.btn_Calcular_Click);
            // 
            // txt_Nome
            // 
            this.txt_Nome.Location = new System.Drawing.Point(184, 69);
            this.txt_Nome.Name = "txt_Nome";
            this.txt_Nome.Size = new System.Drawing.Size(200, 20);
            this.txt_Nome.TabIndex = 1;
            // 
            // lbl_Nome
            // 
            this.lbl_Nome.AutoSize = true;
            this.lbl_Nome.Location = new System.Drawing.Point(96, 72);
            this.lbl_Nome.Name = "lbl_Nome";
            this.lbl_Nome.Size = new System.Drawing.Size(39, 13);
            this.lbl_Nome.TabIndex = 2;
            this.lbl_Nome.Text = "NOME";
            this.lbl_Nome.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_Cargo
            // 
            this.lbl_Cargo.AutoSize = true;
            this.lbl_Cargo.Location = new System.Drawing.Point(96, 107);
            this.lbl_Cargo.Name = "lbl_Cargo";
            this.lbl_Cargo.Size = new System.Drawing.Size(45, 13);
            this.lbl_Cargo.TabIndex = 4;
            this.lbl_Cargo.Text = "CARGO";
            // 
            // txt_Cargo
            // 
            this.txt_Cargo.Location = new System.Drawing.Point(184, 104);
            this.txt_Cargo.Name = "txt_Cargo";
            this.txt_Cargo.Size = new System.Drawing.Size(200, 20);
            this.txt_Cargo.TabIndex = 3;
            // 
            // lbl_Matricula
            // 
            this.lbl_Matricula.AutoSize = true;
            this.lbl_Matricula.Location = new System.Drawing.Point(96, 143);
            this.lbl_Matricula.Name = "lbl_Matricula";
            this.lbl_Matricula.Size = new System.Drawing.Size(69, 13);
            this.lbl_Matricula.TabIndex = 6;
            this.lbl_Matricula.Text = "MÁTRICULA";
            // 
            // txt_Matricula
            // 
            this.txt_Matricula.Location = new System.Drawing.Point(184, 140);
            this.txt_Matricula.Name = "txt_Matricula";
            this.txt_Matricula.Size = new System.Drawing.Size(200, 20);
            this.txt_Matricula.TabIndex = 5;
            // 
            // lbl_Producao
            // 
            this.lbl_Producao.AutoSize = true;
            this.lbl_Producao.Location = new System.Drawing.Point(96, 181);
            this.lbl_Producao.Name = "lbl_Producao";
            this.lbl_Producao.Size = new System.Drawing.Size(68, 13);
            this.lbl_Producao.TabIndex = 8;
            this.lbl_Producao.Text = "PRODUÇÃO";
            // 
            // txt_Producao
            // 
            this.txt_Producao.Location = new System.Drawing.Point(184, 178);
            this.txt_Producao.Name = "txt_Producao";
            this.txt_Producao.Size = new System.Drawing.Size(200, 20);
            this.txt_Producao.TabIndex = 7;
            // 
            // lbl_Salario
            // 
            this.lbl_Salario.AutoSize = true;
            this.lbl_Salario.Location = new System.Drawing.Point(96, 216);
            this.lbl_Salario.Name = "lbl_Salario";
            this.lbl_Salario.Size = new System.Drawing.Size(53, 13);
            this.lbl_Salario.TabIndex = 10;
            this.lbl_Salario.Text = "SALÁRIO";
            // 
            // txt_Salario
            // 
            this.txt_Salario.Location = new System.Drawing.Point(184, 213);
            this.txt_Salario.Name = "txt_Salario";
            this.txt_Salario.Size = new System.Drawing.Size(200, 20);
            this.txt_Salario.TabIndex = 9;
            // 
            // lbl_Gratificacao
            // 
            this.lbl_Gratificacao.AutoSize = true;
            this.lbl_Gratificacao.Location = new System.Drawing.Point(96, 252);
            this.lbl_Gratificacao.Name = "lbl_Gratificacao";
            this.lbl_Gratificacao.Size = new System.Drawing.Size(85, 13);
            this.lbl_Gratificacao.TabIndex = 12;
            this.lbl_Gratificacao.Text = "GRATIFICAÇÃO";
            // 
            // txt_Gratificacao
            // 
            this.txt_Gratificacao.Location = new System.Drawing.Point(184, 249);
            this.txt_Gratificacao.Name = "txt_Gratificacao";
            this.txt_Gratificacao.Size = new System.Drawing.Size(200, 20);
            this.txt_Gratificacao.TabIndex = 11;
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(620, 445);
            this.Controls.Add(this.lbl_Gratificacao);
            this.Controls.Add(this.txt_Gratificacao);
            this.Controls.Add(this.lbl_Salario);
            this.Controls.Add(this.txt_Salario);
            this.Controls.Add(this.lbl_Producao);
            this.Controls.Add(this.txt_Producao);
            this.Controls.Add(this.lbl_Matricula);
            this.Controls.Add(this.txt_Matricula);
            this.Controls.Add(this.lbl_Cargo);
            this.Controls.Add(this.txt_Cargo);
            this.Controls.Add(this.lbl_Nome);
            this.Controls.Add(this.txt_Nome);
            this.Controls.Add(this.btn_Calcular);
            this.Name = "frmExercicio4";
            this.Text = "Exercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Calcular;
        private System.Windows.Forms.TextBox txt_Nome;
        private System.Windows.Forms.Label lbl_Nome;
        private System.Windows.Forms.Label lbl_Cargo;
        private System.Windows.Forms.TextBox txt_Cargo;
        private System.Windows.Forms.Label lbl_Matricula;
        private System.Windows.Forms.TextBox txt_Matricula;
        private System.Windows.Forms.Label lbl_Producao;
        private System.Windows.Forms.TextBox txt_Producao;
        private System.Windows.Forms.Label lbl_Salario;
        private System.Windows.Forms.TextBox txt_Salario;
        private System.Windows.Forms.Label lbl_Gratificacao;
        private System.Windows.Forms.TextBox txt_Gratificacao;
    }
}