﻿namespace Pmatriz
{
    partial class Main
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Exercicio01 = new System.Windows.Forms.Button();
            this.btn_Exercicio02 = new System.Windows.Forms.Button();
            this.btn_Exercicio03 = new System.Windows.Forms.Button();
            this.btn_Exercicio04 = new System.Windows.Forms.Button();
            this.btn_Exercicio05 = new System.Windows.Forms.Button();
            this.btn_Exercicio06 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Exercicio01
            // 
            this.btn_Exercicio01.Location = new System.Drawing.Point(256, 138);
            this.btn_Exercicio01.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Exercicio01.Name = "btn_Exercicio01";
            this.btn_Exercicio01.Size = new System.Drawing.Size(163, 54);
            this.btn_Exercicio01.TabIndex = 0;
            this.btn_Exercicio01.Text = "Exercício 01";
            this.btn_Exercicio01.UseVisualStyleBackColor = true;
            this.btn_Exercicio01.Click += new System.EventHandler(this.Btn_Exercicio01_Click);
            // 
            // btn_Exercicio02
            // 
            this.btn_Exercicio02.Location = new System.Drawing.Point(443, 138);
            this.btn_Exercicio02.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Exercicio02.Name = "btn_Exercicio02";
            this.btn_Exercicio02.Size = new System.Drawing.Size(163, 54);
            this.btn_Exercicio02.TabIndex = 1;
            this.btn_Exercicio02.Text = "Exercício 02";
            this.btn_Exercicio02.UseVisualStyleBackColor = true;
            this.btn_Exercicio02.Click += new System.EventHandler(this.btn_Exercicio02_Click);
            // 
            // btn_Exercicio03
            // 
            this.btn_Exercicio03.Location = new System.Drawing.Point(631, 138);
            this.btn_Exercicio03.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Exercicio03.Name = "btn_Exercicio03";
            this.btn_Exercicio03.Size = new System.Drawing.Size(163, 54);
            this.btn_Exercicio03.TabIndex = 2;
            this.btn_Exercicio03.Text = "Exercício 03";
            this.btn_Exercicio03.UseVisualStyleBackColor = true;
            this.btn_Exercicio03.Click += new System.EventHandler(this.btn_Exercicio03_Click);
            // 
            // btn_Exercicio04
            // 
            this.btn_Exercicio04.Location = new System.Drawing.Point(256, 362);
            this.btn_Exercicio04.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Exercicio04.Name = "btn_Exercicio04";
            this.btn_Exercicio04.Size = new System.Drawing.Size(163, 54);
            this.btn_Exercicio04.TabIndex = 3;
            this.btn_Exercicio04.Text = "Exercício 04";
            this.btn_Exercicio04.UseVisualStyleBackColor = true;
            this.btn_Exercicio04.Click += new System.EventHandler(this.btn_Exercicio04_Click);
            // 
            // btn_Exercicio05
            // 
            this.btn_Exercicio05.Location = new System.Drawing.Point(443, 362);
            this.btn_Exercicio05.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Exercicio05.Name = "btn_Exercicio05";
            this.btn_Exercicio05.Size = new System.Drawing.Size(163, 54);
            this.btn_Exercicio05.TabIndex = 4;
            this.btn_Exercicio05.Text = "Exercício 05";
            this.btn_Exercicio05.UseVisualStyleBackColor = true;
            this.btn_Exercicio05.Click += new System.EventHandler(this.btn_Exercicio05_Click);
            // 
            // btn_Exercicio06
            // 
            this.btn_Exercicio06.Location = new System.Drawing.Point(631, 362);
            this.btn_Exercicio06.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Exercicio06.Name = "btn_Exercicio06";
            this.btn_Exercicio06.Size = new System.Drawing.Size(163, 54);
            this.btn_Exercicio06.TabIndex = 5;
            this.btn_Exercicio06.Text = "Exercício 06";
            this.btn_Exercicio06.UseVisualStyleBackColor = true;
            this.btn_Exercicio06.Click += new System.EventHandler(this.btn_Exercicio06_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.btn_Exercicio06);
            this.Controls.Add(this.btn_Exercicio05);
            this.Controls.Add(this.btn_Exercicio04);
            this.Controls.Add(this.btn_Exercicio03);
            this.Controls.Add(this.btn_Exercicio02);
            this.Controls.Add(this.btn_Exercicio01);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Main";
            this.Text = "Início";
            this.Load += new System.EventHandler(this.Main_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Exercicio01;
        private System.Windows.Forms.Button btn_Exercicio02;
        private System.Windows.Forms.Button btn_Exercicio03;
        private System.Windows.Forms.Button btn_Exercicio04;
        private System.Windows.Forms.Button btn_Exercicio05;
        private System.Windows.Forms.Button btn_Exercicio06;
    }
}

